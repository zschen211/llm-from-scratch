from .bpe_core import *

__doc__ = bpe_core.__doc__
if hasattr(bpe_core, "__all__"):
    __all__ = bpe_core.__all__